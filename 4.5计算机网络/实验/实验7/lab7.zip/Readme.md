# 实验环境

<img src="C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20211223190424900.png" alt="image-20211223190424900" style="zoom:50%;" />

![image-20211223190615544](C:\Users\huawei\AppData\Roaming\Typora\typora-user-images\image-20211223190615544.png)



# 文件说明

- 实验报告在report文件夹下

- C语言源代码以及linux系统可运行文件在source code文件夹下。其中：

  - client.c为客户端源代码，server.c为服务器端源代码
  - cli为客户端可执行文件，ser为服务端可执行文件

  

# 使用说明

1. 在linux终端下执行ser文件
2. 然后执行cli文件即可运行