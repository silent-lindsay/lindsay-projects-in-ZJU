#!/bin/bash
folder="./test"
files=$(ls ${folder}/*.pas)

for f in $files
do 
    # echo "----- ${f} IR generation -------"
    cat ${f} | ./spl 2>${f%pas*}ll 1>/dev/null
    # echo "-------- ${f} output ----------"
    lli ${f%pas*}ll 1>${f%pas*}txt
    if [ $? -eq 0 ]; then
        # echo "file ${f} run succeed"
        :
    else
        echo "file ${f} run failed, error code [$?]"
    fi
    # echo "----------- end ----------"
done

# source code -> AST -> LLVM IR -> LLVM Bytecode -> ASM -> Native 
#   (.pas)       (.c)   (.ll)       (.bc)           (.s)    (exe)    