input.txt是测试文件
lab2.sh是处理批量编译命令
lex.yy.c，lab2.tab.c和lab2.tab.h是生成的中间文件，
parser是linux下可执行文件

实验环境：
Ubuntu18.04(64位)操作系统
命令行编译：
运行sh lab1.sh或运行./parser < input.txt或运行./parser（此时命令行输入，q结束输入）