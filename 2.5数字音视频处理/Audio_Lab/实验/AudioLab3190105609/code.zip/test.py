from scipy.io import wavfile
import matplotlib.pyplot as plt
import numpy as np

# print("read wav...",fname)
# f = open(r"N2.wav")
# rate , signal = wavfile.read(f)
rate, signal = wavfile.read(r"3190105609-W1\\train\\N1.wav")
if len(signal.shape) != 1:
    print("convert stereo to mono")
    signal = signal[:,0]
length = signal.shape[0]/rate
time = np.linspace(0., length, signal.shape[0])
# print(len(signal),signal)
print("finished length is",length)

plt.plot(time, signal, label="Single channel")
# plt.plot(time, signal[:, 1], label="Right channel")
plt.legend()
plt.xlabel("Time [s]")
plt.ylabel("Amplitude")
plt.show()