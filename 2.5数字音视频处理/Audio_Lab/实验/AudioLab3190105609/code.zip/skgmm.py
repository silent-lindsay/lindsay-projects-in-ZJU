from sklearn.mixture import GaussianMixture
import numpy as np
import math

class GMMSet:

    def __init__(self, gmm_order = 32):
        self.gmms = []
        self.gmm_order = gmm_order
        self.y = []

    def fit_new(self, x, label):
        self.y.append(label)
        gmm = GaussianMixture(self.gmm_order)
        gmm.fit(x)
        self.gmms.append(gmm)

    def gmm_score(self, gmm, x):
        return np.sum(gmm.score(x))
        
    def predict_one(self, x):
        scores = [self.gmm_score(gmm, x) / len(x) for gmm in self.gmms] # get average scores of all gaussian mixture models
        return math.exp( np.mean(scores) ) # exp the average of scores

    def before_pickle(self):
        pass

    def after_pickle(self):
        pass
