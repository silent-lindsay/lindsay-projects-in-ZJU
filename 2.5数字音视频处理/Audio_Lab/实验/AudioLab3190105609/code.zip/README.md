### Files
directory 3190105609-W* contains the wav files record audios of each week
directory xtl is others' audio records for testing the accuracy of module

### Usage

usage: speaker-recognition.py [-h] -t TASK -i INPUT -m MODEL

Speaker Recognition Command Line Tool

optional arguments:
  -h, --help            show this help message and exit
  -t TASK, --task TASK  Task to do. Either "enroll" or "predict"
  -i INPUT, --input INPUT
                        Input Files(to predict) or Directories(to enroll)
  -m MODEL, --model MODEL
                        Model file to save(in enroll) or use(in predict)

Wav files in each input directory will be labeled as the basename of the directory.
Note that wildcard inputs should be *quoted*, and they will be sent to glob module.

Examples:
    Train:
    py speaker-recognition.py -t enroll -i "3190105609-W1\train" -m model.out

    Predict:
    py speaker-recognition.py -t predict -i "3190105609-W1\*.wav" -m model.out