from scipy.io import wavfile
import librosa

def read_wav(fname):
    # signal,rate = librosa.load(fname)
    # print("read wav...",fname)
    rate, signal = wavfile.read(fname)
    if len(signal.shape) != 1:
        print("convert stereo to mono")
        signal = signal[:,0]
    return rate, signal
