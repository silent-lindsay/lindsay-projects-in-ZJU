#pragma once

#include "types.h"

void* memset(void *, int, uint64);