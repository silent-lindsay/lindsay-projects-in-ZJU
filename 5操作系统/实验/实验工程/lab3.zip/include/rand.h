#include "types.h"

#define SEED 10007
uint64 rand();
