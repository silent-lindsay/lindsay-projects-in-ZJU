#ifndef _PRINT_H
#define _PRINT_H

void puts(char *s);
void puti(int x);

#endif
